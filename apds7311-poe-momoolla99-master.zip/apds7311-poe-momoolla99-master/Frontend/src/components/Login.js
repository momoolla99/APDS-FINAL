import React, { useState } from 'react';
import axios from 'axios';
import './Login.css';

const Login = ({ setToken, navigateToRegister, navigate }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post(
                'http://localhost:5000/api/users/login',
                { username, password },
                { headers: { 'Content-Type': 'application/json' } }
            );

            const user = response.data.user;

            setToken(response.data.token);
            localStorage.setItem('token', response.data.token);

            if (user.role === 'employee') {
                navigate('/employeedashboard');
            } else {
                navigate('/paymentform');
            }
        } catch (error) {
            if (error.response) {
                setMessage(error.response.data.message);
            } else {
                setMessage('An unexpected error occurred. Please try again.');
            }
        }
    };

    return (
        <div className="login-container">
            <h2 className="login-title">Login</h2>
            <form className="login-form" onSubmit={handleLogin}>
                <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Username"
                    required
                    className="login-input"
                />
                <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password"
                    required
                    className="login-input"
                />
                <button type="submit" className="login-button">Login</button>
                {message && <p className="login-message">{message}</p>}
            </form>
            <p className="register-prompt">
                Don't have an account?{' '}
                <button onClick={navigateToRegister} className="register-button">Register</button>
            </p>
        </div>
    );
};

export default Login;
