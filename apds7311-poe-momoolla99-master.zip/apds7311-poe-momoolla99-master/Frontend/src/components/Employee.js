import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './EmployeeDashboard.css';

const TransactionDashboard = () => {
    const [transactions, setTransactions] = useState([]);
    const [message, setMessage] = useState('');
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchTransactions = async () => {
            try {
                const token = localStorage.getItem('token');
                if (!token) {
                    setMessage('No token found');
                    return;
                }

                const response = await axios.get('http://localhost:5000/api/transactions', {
                    headers: { Authorization: `Bearer ${token}` }
                });

                setTransactions(response.data);
                setIsLoading(false);
            } catch (error) {
                console.error("Error fetching transactions:", error);
                setMessage('Failed to load transactions');
                setIsLoading(false);
            }
        };

        fetchTransactions();
    }, []);

    const handleVerify = async (transactionId) => {
        try {
            const token = localStorage.getItem('token');
            if (!token) {
                setMessage('No token found');
                return;
            }

            await axios.put(
                `http://localhost:5000/api/transactions/verify/${transactionId}`,
                {},
                { headers: { Authorization: `Bearer ${token}` } }
            );
            setMessage('Transaction verified successfully!');
            setTransactions(prev =>
                prev.map(transaction =>
                    transaction._id === transactionId ? { ...transaction, status: 'Verified' } : transaction
                )
            );
        } catch (error) {
            console.error("Verification failed:", error);
            setMessage('Verification failed');
        } finally {
            setTimeout(() => setMessage(''), 3000);
        }
    };

    const handleSubmitToSwift = async (transactionId) => {
        try {
            const token = localStorage.getItem('token');
            if (!token) {
                setMessage('No token found');
                return;
            }

            await axios.put(
                `http://localhost:5000/api/transactions/submit-to-swift/${transactionId}`,
                {},
                { headers: { Authorization: `Bearer ${token}` } }
            );
            setMessage('Transaction submitted to SWIFT successfully!');
            setTransactions(prev =>
                prev.map(transaction =>
                    transaction._id === transactionId ? { ...transaction, status: 'Submitted to SWIFT' } : transaction
                )
            );
        } catch (error) {
            console.error("Submission failed:", error);
            setMessage('Submission failed');
        } finally {
            setTimeout(() => setMessage(''), 3000);
        }
    };

    return (
        <div className="transaction-dashboard-container">
            <h2>Employee Transaction Dashboard</h2>
            {message && <p className="message">{message}</p>}
            {isLoading ? (
                <div className="loading-spinner">Loading...</div> /* Added a spinner */
            ) : (
                <div className="transaction-list">
                    {transactions.length > 0 ? (
                        transactions.map((transaction) => (
                            <div key={transaction._id} className="transaction-card">
                                <div className="transaction-details">
                                    <p><strong>Payee:</strong> {transaction.payeeAccountNumber}</p>
                                    <p><strong>Amount:</strong> {transaction.amount} {transaction.currency}</p>
                                    <p><strong>Status:</strong> {transaction.status}</p>
                                </div>
                                <div className="button-group">
                                    <button
                                        className="verify-button"
                                        onClick={() => handleVerify(transaction._id)}
                                        disabled={transaction.status === 'Verified'}
                                    >
                                        Verify
                                    </button>
                                    <button
                                        className="submit-button"
                                        onClick={() => handleSubmitToSwift(transaction._id)}
                                        disabled={transaction.status === 'Submitted to SWIFT'}
                                    >
                                        Submit to SWIFT
                                    </button>
                                </div>
                            </div>
                        ))
                    ) : (
                        <p>No transactions available.</p>
                    )}
                </div>
            )}
        </div>
    );
};

export default TransactionDashboard;
