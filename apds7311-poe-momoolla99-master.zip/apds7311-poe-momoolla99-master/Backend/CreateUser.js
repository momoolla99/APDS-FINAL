console.log("Starting the createUser script...");

require('dotenv').config();
console.log("Environment variables loaded.");
console.log("MONGODB_URI:", process.env.MONGODB_URI);

const mongoose = require('mongoose');
const User = require('./models/User'); 
const connectDB = require('./config/db'); 
const bcrypt = require('bcrypt');


connectDB()
    .then(() => {
        console.log("Database connected.");
        return createUser('allowedUser1', 'StrongPass@123');
    })
    .catch(err => {
        console.error("Database connection error:", err);
        process.exit(1); 
    });


const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;


const createUser = async (username, password) => {
    try {
       
        if (!passwordRegex.test(password)) {
            throw new Error('Password does not meet the required complexity.');
        }

        const existingUser = await User.findOne({ username });
        if (existingUser) {
            throw new Error('Username already exists');
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        console.log(`Creating user ${username} with hashed password: ${hashedPassword}`); 
        
        const newUser = new User({ username, password: hashedPassword });
        await newUser.save();
        console.log(`User ${username} created successfully.`);
    } catch (error) {
        console.error("Error creating user:", error.message);
    }
};
