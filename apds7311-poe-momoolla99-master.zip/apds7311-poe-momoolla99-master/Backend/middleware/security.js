const rateLimit = require('express-rate-limit');
const helmet = require('helmet');

const setSecurityHeaders = helmet();  


const hstsMiddleware = helmet.hsts({
    maxAge: 31536000, 
    includeSubDomains: true,
    preload: true
});


const limiter = rateLimit({
    windowMs: 20 * 60 * 1000, 
    max: 100, 
    message: "Too many requests from this IP, try again later." 
});

module.exports = {
    setSecurityHeaders,
    hstsMiddleware,
    limiter,
};

