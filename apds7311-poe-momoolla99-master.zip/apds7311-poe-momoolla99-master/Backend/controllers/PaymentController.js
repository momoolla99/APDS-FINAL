
const User = require('../models/User'); 
const Transaction = require('../models/Transactions');
const Payment = require('../models/Payment');

const createPayment = async (req, res) => {
    console.log('Received payment :', req.body);
    const { amount, currency, swiftCode, recipientAccountNumber } = req.body;


    if (!amount || !currency || !swiftCode || !recipientAccountNumber) {
        return res.status(400).json({ message: 'All fields are required: amount, currency, swift code, recipient account number' });
    }

    
    const amountNumber = Number(amount);
    if (isNaN(amountNumber) || amountNumber <= 0) {
        return res.status(400).json({ message: 'Amount must be a positive number' });
    }

    
    const formattedCurrency = currency.toUpperCase();

    try {
        
        const user = await User.findById(req.user.userId); 
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        
        const newTransaction = new Transaction({
            payeeAccountNumber: user.accountNumber, 
            currency: formattedCurrency,
            amount: amountNumber,
            swiftCode,
            status: 'Pending'
        });
        await newTransaction.save();

       
        const newPayment = new Payment({
            userId: req.user.userId, 
            amount: amountNumber,
            currency: formattedCurrency,
            swiftCode,
            recipientAccountNumber,
            transactionId: newTransaction._id  
        });
        await newPayment.save();

        res.status(201).json({
            message: 'Payment and Transaction created !',
            payment: newPayment,
            transaction: newTransaction
        });
    } catch (error) {
        console.error('Error creating payment:', error);
        if (error.name === 'ValidationError') {
            return res.status(400).json({ message: 'Validation error', errors: error.errors });
        }
        res.status(500).json({
            message: 'Internal Server Error: Could not create payment and transaction',
            error: {
                name: error.name,
                message: error.message
            }
        });
    }
};


const getPayments = async (req, res) => {
    try {
        console.log('User ID:', req.user.userId); 

        const payments = await Payment.find({ userId: req.user.userId }).populate('transactionId');
        
        console.log('Payments found:', payments); 

        if (!payments.length) {
            return res.status(404).json({ message: 'No payments found' });
        }

        res.status(200).json(payments);
    } catch (error) {
        console.error('Error fetching payments:', error);
        res.status(500).json({ message: 'Internal Server Error: Could not fetch payments' });
    }
};

module.exports = { createPayment, getPayments };
