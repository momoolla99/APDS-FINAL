
const User = require('../models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../config/jwt');
const crypto = require('crypto');


const usernameRegex = /^[a-zA-Z0-9._@-]{3,30}$/; 
const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/; 
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; 

const generateAccountNumber = (userId) => {
    const hash = crypto.createHash('kho456').update(userId).digest('hex');
    return 'AC' + hash.substring(0, 10).toUpperCase(); 
};


const register = async (username, email, password) => {
    try {
      
        if (!usernameRegex.test(username)) {
            throw new Error('Username must be between 5 and 30 characters and can only contain letters, numbers, underscores, dots, and hyphens.');
        }
        if (!emailRegex.test(email)) {
            throw new Error('Invalid email format');
        }
        if (!passwordRegex.test(password)) {
            throw new Error('Password must be at least 8 characters long and include uppercase letters, lowercase letters, numbers, and special characters.');
        }

        
        const existingUsername = await User.findOne({ username });
        if (existingUsername) throw new Error('Username already taken');
        const existingEmail = await User.findOne({ email });
        if (existingEmail) throw new Error('Email already in use');

       
        const hashedPassword = await bcrypt.hash(password, 10);

        
        const newUser = new User({
            username,
            email,
            password: hashedPassword,
            role: 'user',
        });
        newUser.accountNumber = generateAccountNumber(newUser._id.toString());

        
        await newUser.save();

       
        const token = jwt.sign(
            { userId: newUser._id, username: newUser.username, role: newUser.role },
            JWT_SECRET,
            { expiresIn: '1h' }
        );

        return { newUser, token };
    } catch (error) {
        console.error('Register error:', error.message);
        throw error;
    }
};


const login = async (username, password) => {
    try {
        
        if (!usernameRegex.test(username)) {
            throw new Error('Username must be between 5 and 30 characters and can only contain letters, numbers, dots, underscores, and hyphens.');
        }
        if (!passwordRegex.test(password)) {
            throw new Error('Password must be at least 8 characters long and include uppercase letters, lowercase letters, numbers, and special characters.');
        }

        
        const user = await User.findOne({ username });
        if (!user) throw new Error('Invalid username or password');

       
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) throw new Error('Invalid password');

       
        const token = jwt.sign(
            { userId: user._id, username: user.username, role: user.role },
            JWT_SECRET,
            { expiresIn: '1h' }
        );

        return { user, token };
    } catch (error) {
        console.error('Login error:', error.message);
        throw error;
    }
};

module.exports = { register, login };
