const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const { checkAuth } = require('../middleware/auth');
const rateLimit = require('express-rate-limit');  

const router = express.Router();

const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;


const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 5, 
    message: 'Too many login attempts. Try again later.'
});



router.post('/register', async (req, res) => {
    let { username, password } = req.body;

   
    username = username.trim();
    password = password.trim();

   
    if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
    }

 
    console.log('Username:', username);
    console.log('Password:', password);

 
    if (!usernameRegex.test(username)) {
        return res.status(400).json({ message: 'Username must be alphanumeric with underscores, 3-20 characters long' });
    }

    
    if (!passwordRegex.test(password)) {
        return res.status(400).json({ message: 'Password must be at least 8 characters long, contain uppercase, lowercase, a number, and a special character' });
    }

    try {
       
        const userExists = await User.findOne({ username });
        if (userExists) {
            return res.status(400).json({ message: 'Username already exists' });
        }

        const hashedPassword = await bcrypt.hash(password, 10); 

        
        const newUser = new User({
            username,
            password: hashedPassword,
            role: 'user', 
        });

  
        await newUser.save();

      
        const token = jwt.sign(
            { userId: newUser._id, username: newUser.username, role: newUser.role },
            process.env.JWT_SECRET || 'your_jwt_secret',
            { expiresIn: '1h' }
        );

        
        res.status(201).json({ token });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});



router.post('/login', loginLimiter, async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
    }

    try {
        
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(400).json({ message: 'Invalid username or password' });
        }

        
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid username or password' });
        }

       
        const token = jwt.sign(
            { userId: user._id, username: user.username, role: user.role },
            process.env.JWT_SECRET || 'your_jwt_secret',
            { expiresIn: '1h' }
        );

        
        res.json({ user, token });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});


router.get('/employee/dashboard', checkAuth, (req, res) => {
    if (req.user.role === 'employee') {
        res.json({ message: 'Welcome to the Employee Dashboard' });
    } else {
        res.status(403).json({ message: 'Access forbidden: Employees only' });
    }
});

module.exports = router;
