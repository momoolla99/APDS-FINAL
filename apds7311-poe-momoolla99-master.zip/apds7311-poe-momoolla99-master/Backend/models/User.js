const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const crypto = require('crypto');

const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        unique: true,
    },
    password: {
        type: String,
        required: true,
    },
    role: { 
        type: String, 
        enum: ['user'], 
        required: true 
    }, 
    accountNumber: {
        type: String,
        unique: true,
    }
});


userSchema.pre('save', async function (next) {
    if (this.isModified('password')) {
        console.log('Hashing password for user:', this.username); 
        this.password = await bcrypt.hash(this.password, 10);
    }
    
    
    if (!this.accountNumber) {
        console.log('Generating account number for user:', this.username); 
        const hash = crypto.createHash('sha256').update(this._id.toString()).digest('hex');
        this.accountNumber = 'AC' + hash.substring(0, 10).toUpperCase(); 
    }

    next();
});

const User = mongoose.model('User', userSchema);

module.exports = User;
